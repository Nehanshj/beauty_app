package com.ankansikdar.expense_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
